import React from 'react';
import { render } from 'react-dom';
import Counter from './Counter';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import {reducer} from './Reducer'


const store = // create store

const App = () => (
  <Provider store={store}>
    // add component
  </Provider>
);

render(<App />, document.getElementById('root'));

