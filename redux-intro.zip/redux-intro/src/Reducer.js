
const initialState = {
    count: 0
};
function reducer(state = initialState, action) {
    switch(action.type) {
        case 'INCREMENT':
            return {
                //add new state
            };
        case 'DECREMENT':
            return {
                //add new state
            };
        default:
            return state;
    }
}

export {reducer};